
import React, { useState } from 'react';

export default function Home() {
  const [step, setStep] = useState(1);
  const [logo, setLogo] = useState(null);
  const [content, setContent] = useState(null);
  const [questionTypes, setQuestionTypes] = useState([]);
  const [questionConfig, setQuestionConfig] = useState([]);
  const [fileFormat, setFileFormat] = useState('PDF');
  const [downloadLink, setDownloadLink] = useState(null);

  const handleUpload = (e, setter) => {
    const file = e.target.files[0];
    if (file) setter(file.name);
  };

  const handleGenerate = () => {
    const fakeLink = `https://download.fake/${Date.now()}.${fileFormat.toLowerCase()}`;
    setDownloadLink(fakeLink);
    setStep(5);
  };

  return (
    <div className="min-h-screen bg-white p-8">
      <h1 className="text-3xl font-bold mb-6 text-center">🧠 AIExamPro - Question Paper Generator</h1>

      {step === 1 && (
        <div className="space-y-4">
          <label className="block">
            Upload Logo:
            <input type="file" accept="image/*" onChange={(e) => handleUpload(e, setLogo)} />
          </label>
          <button
            className="bg-blue-500 text-white px-4 py-2 rounded"
            onClick={() => setStep(2)}
          >
            Next: Upload Content
          </button>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-4">
          <label className="block">
            Upload Content (Image, PDF, Text, YouTube/Link):
            <input type="file" onChange={(e) => handleUpload(e, setContent)} />
          </label>
          <button className="bg-gray-300 px-4 py-2" onClick={() => setStep(1)}>⬅️ Back</button>
          <button className="bg-blue-500 text-white px-4 py-2" onClick={() => setStep(3)}>
            Next: Select Question Type
          </button>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Select Question Types:</h2>
          {['MCQ', 'True/False', 'Match the Following', 'Fill in the Blanks'].map((type) => (
            <label key={type} className="block">
              <input
                type="checkbox"
                onChange={(e) => {
                  setQuestionTypes((prev) =>
                    e.target.checked ? [...prev, type] : prev.filter((q) => q !== type)
                  );
                }}
              />{' '}
              {type}
            </label>
          ))}

          <button className="bg-gray-300 px-4 py-2" onClick={() => setStep(2)}>⬅️ Back</button>
          <button className="bg-blue-500 text-white px-4 py-2" onClick={() => setStep(4)}>
            Next: Configure Questions
          </button>
        </div>
      )}

      {step === 4 && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Question Configuration:</h2>
          {questionTypes.map((type) => (
            <div key={type} className="space-y-2">
              <p className="font-semibold">{type}</p>
              <label>
                How many questions?
                <input
                  type="number"
                  className="border p-1 ml-2"
                  onChange={(e) => {
                    const q = questionConfig.filter((qc) => qc.type !== type);
                    setQuestionConfig([...q, { type, count: e.target.value, marks: 1 }]);
                  }}
                />
              </label>
              <label className="ml-4">
                Marks per question:
                <input
                  type="number"
                  className="border p-1 ml-2"
                  onChange={(e) => {
                    const q = questionConfig.filter((qc) => qc.type !== type);
                    setQuestionConfig([...q, { type, count: 1, marks: e.target.value }]);
                  }}
                />
              </label>
            </div>
          ))}

          <label>
            File format:
            <select onChange={(e) => setFileFormat(e.target.value)} className="ml-2 border p-1">
              <option>PDF</option>
              <option>DOCX</option>
            </select>
          </label>

          <button className="bg-gray-300 px-4 py-2" onClick={() => setStep(3)}>⬅️ Back</button>
          <button className="bg-green-600 text-white px-4 py-2" onClick={handleGenerate}>
            ✅ Generate Question Paper
          </button>
        </div>
      )}

      {step === 5 && (
        <div className="text-center space-y-4">
          <h2 className="text-xl font-bold">🎉 Question Paper Ready!</h2>
          <p>Click below to download your file:</p>
          <a
            href={downloadLink}
            download
            className="text-blue-600 underline"
          >
            Download {fileFormat}
          </a>
          <br />
          <button
            className="mt-4 bg-blue-400 text-white px-4 py-2"
            onClick={() => {
              setStep(1);
              setLogo(null);
              setContent(null);
              setQuestionTypes([]);
              setQuestionConfig([]);
              setFileFormat('PDF');
              setDownloadLink(null);
            }}
          >
            🔁 Start Over
          </button>
        </div>
      )}
    </div>
  );
}
